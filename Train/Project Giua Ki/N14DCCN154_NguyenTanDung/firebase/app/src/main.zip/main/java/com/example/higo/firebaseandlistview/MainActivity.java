package com.example.higo.firebaseandlistview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    Button btnClick;
    ListView lvUser;
    EditText edUsername,edEmail;
    ArrayList<User> arrayList;
    MyArrayAdapter myArrayAdapter;
    FirebaseDatabase database;
    DatabaseReference myref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControls();
        addEvents();

    }

    private void addEvents() {
        btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                User user = new User();
                user.setUserName(edUsername.getText()+"");
                user.setEmail(edEmail.getText()+"");
                //arrayList.add(user);
                //myArrayAdapter.notifyDataSetChanged();
                //String userId = myref.push().getKey();
                myref.push().setValue(user);
            }
        });


        myref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                showData(dataSnapshot);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }

    private void showData(DataSnapshot dataSnapshot) {
        arrayList.clear();
        for(DataSnapshot ds : dataSnapshot.getChildren()){
            User user = new User();
            user.setUserName(ds.getValue(User.class).getUserName());
            user.setEmail(ds.getValue(User.class).getEmail());
            arrayList.add(user);

        }
        myArrayAdapter.notifyDataSetChanged();
    }

    private void addControls() {
        lvUser = findViewById(R.id.lvUser);
        edUsername = findViewById(R.id.edUsername);
        edEmail = findViewById(R.id.edEmail);
        myref = FirebaseDatabase.getInstance().getReference("User");
        arrayList = new ArrayList<>();
        btnClick = findViewById(R.id.btnClick);

        myArrayAdapter = new MyArrayAdapter(this,R.layout.item,arrayList);
        lvUser.setAdapter(myArrayAdapter);


    }
}
