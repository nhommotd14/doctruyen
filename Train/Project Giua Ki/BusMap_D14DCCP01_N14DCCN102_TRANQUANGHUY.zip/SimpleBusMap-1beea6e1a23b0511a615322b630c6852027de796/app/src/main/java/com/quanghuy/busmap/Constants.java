package com.quanghuy.busmap;

/**
 * Created by Huy on 4/19/2018.
 */

public class Constants {
    public static final String PACKAGE_NAME = "com.quanghuy.busmap";
}
